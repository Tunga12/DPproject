package sample;

import javafx.collections.ObservableList;

import java.util.ArrayList;
import java.util.Comparator;

public class SortDecorator extends DisplayDecorator {

    public SortDecorator(ProductDisplay DecoratedProduct) {
        super(DecoratedProduct);
    }


    public ObservableList<product> productName(ObservableList<product> list) {

        DecoratedProduct.productName(list);
        sort( list);

        return sort( list);
    }
    public ObservableList<product> sort(ObservableList<product> list){

        Comparator<product> comparator = Comparator.comparing(product::getName);
        list.sort(comparator);
        ArrayList<String> arr = new ArrayList<>();

        for(int i = 0;i<list.size();i++){
            arr.add(list.get(i).getName());
            System.out.println(list.get(i).getName() +"\n");
        }

        return list;

    }
}
