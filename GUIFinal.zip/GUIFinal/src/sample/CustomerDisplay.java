package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class CustomerDisplay implements ProductDisplay {

    @Override
    public ObservableList<product> productName(ObservableList<product> list) {

        ObservableList<product> productNameOnly = FXCollections.observableArrayList();
        ArrayList<String> arr = new ArrayList<>();
        for(int i = 0 ; i < list.size();i++){
            // l.add(new product(list.get(i).getName()));
            productNameOnly.add(new product(list.get(i).getName()));

        }

        return productNameOnly;
    }
}
