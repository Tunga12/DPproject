package sample;

import javafx.collections.ObservableList;

public  class DisplayDecorator implements ProductDisplay {

    protected ProductDisplay DecoratedProduct;
    public DisplayDecorator(ProductDisplay DecoratedProduct){
            this.DecoratedProduct = DecoratedProduct;

    }
    @Override
    public ObservableList<product> productName(ObservableList<product> list) {
            DecoratedProduct.productName(list);
        return DecoratedProduct.productName(list);
    }
}
