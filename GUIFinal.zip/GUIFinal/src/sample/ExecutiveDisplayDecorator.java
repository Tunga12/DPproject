package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ExecutiveDisplayDecorator extends DisplayDecorator {

    public ExecutiveDisplayDecorator(ProductDisplay DecoratedProduct) {
        super(DecoratedProduct);
    }

    public ObservableList<product> productName(ObservableList<product> list) {

          DecoratedProduct.productName(list);
          numberOfProductBought(list);

        ObservableList<product> listForExecutive = FXCollections.observableArrayList();
        System.out.println("Displaying products for Executive Display");
        System.out.println("productName" +"\t\t" +"number of shipped");

          for(int i =0 ;i < DecoratedProduct.productName(list).size() ;i++){
              System.out.println(DecoratedProduct.productName(list).get(i).name + "\t\t\t" + numberOfProductBought(list).get(i).bought);
              listForExecutive.add(new product(DecoratedProduct.productName(list).get(i).getName(),numberOfProductBought(list).get(i).getBought()));
        }

        return listForExecutive;
    }

    public ObservableList<product> numberOfProductBought(ObservableList<product> list){
        ObservableList<product> justList1 = FXCollections.observableArrayList();
        for(int i =0 ;i < list.size() ;i++){
            justList1.add(new product(list.get(i).bought));

        }

        return justList1;
    }
}
