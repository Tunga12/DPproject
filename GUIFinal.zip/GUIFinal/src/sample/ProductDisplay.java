package sample;

import javafx.collections.ObservableList;

import java.util.ArrayList;

public interface ProductDisplay {

    public ObservableList<product> productName(ObservableList<product> list);
}
