package sample;

import java.util.ArrayList;

public class Employee {

    private String name;
    private String role;
    private int salary;

    private String output = "";

    private ArrayList<Employee> subordinates;

    public Employee(String name, String role, int salary) {
        this.name = name;
        this.role = role;
        this.salary = salary;
        subordinates = new ArrayList<>();
    }

    public void add(Employee e) {
        subordinates.add(e);
    }

    public void remove(Employee e) {
        subordinates.remove(e);
    }

    public int getSalary() {
        return salary;
    }

    public ArrayList<Employee> getSubordinates(){

        return subordinates;
    }

    public String getName() {
        return name;
    }

    public  String display(int depth) {

        output += new String(new char[depth]).replace("\0", "-") + role + ": "+ name + " " + salary + "\n";
        // Recursively display child nodes
        for(Employee e : subordinates) {
            output += e.display(depth + 2);
        }

        String last = output;
        output = "";
        return last;

    }

    public int costOfControlSpan(){
        int totalSalary = salary;

        for(Employee e : subordinates) {
            totalSalary += e.costOfControlSpan();
        }

        return totalSalary;
    }

}

