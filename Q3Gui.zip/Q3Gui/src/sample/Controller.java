package sample;

import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    ArrayList<Employee> employees = new ArrayList<>();
    Employee CEO = new Employee("John","CEO", 30000);
    Employee headSales = new Employee("Robert","Head Sales", 20000);
    Employee headMarketing = new Employee("Michel","Head Marketing", 20000);
    Employee clerk1 = new Employee("Laura","Marketing", 10000);
    Employee clerk2 = new Employee("Bob","Marketing", 10000);
    Employee salesExecutive1 = new Employee("Richard","Sales", 10000);
    Employee salesExecutive2 = new Employee("Rob","Sales", 10000);


    public TextArea orgView, costSpan;
    public TextField txtName, txtRole, txtSalary;
    public ComboBox comboSuccessor, comboEmp;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        employees.add(CEO);
        employees.add(headSales);
        employees.add(headMarketing);
        employees.add(clerk1);
        employees.add(clerk2);
        employees.add(salesExecutive1);
        employees.add(salesExecutive2);

        CEO.add(headSales);
        CEO.add(headMarketing);
        headSales.add(salesExecutive1);
        headSales.add(salesExecutive2);
        headMarketing.add(clerk1);
        headMarketing.add(clerk2);

        String output = CEO.display(1);
        orgView.setText(output);

        for(Employee e: employees){
            comboSuccessor.getItems().add(e.getName());
            comboEmp.getItems().add(e.getName());
        }
    }

    public void AddClicked(){

        Employee newEmp = new Employee(txtName.getText(), txtRole.getText(), Integer.parseInt(txtSalary.getText()));
        employees.add(newEmp);
        String sucessorName = (String) comboSuccessor.getValue();
        Employee sucessor = null;
        for(Employee e: employees){
            if(e.getName().equals(sucessorName)){
                sucessor = e;
            }
        }
        sucessor.add(newEmp);

        String output = CEO.display(1);
        orgView.setText(output);

        comboSuccessor.getItems().add(newEmp.getName());
        comboEmp.getItems().add(newEmp.getName());
    }


    public void ViewClicked(){

        String employeeName = (String) comboEmp.getValue();
        Employee emp = null;
        for(Employee e: employees){
            if(e.getName().equals(employeeName)){
               emp  = e;
            }
        }

        costSpan.setText(emp.getName() + "'s total cost of control span is: " + emp.costOfControlSpan());


    }
}
