package sample;

import java.util.ArrayList;

public class Swimmer {

    private String name;
    private Sex sex;
    private int age;
    private AgeGroup ageGroup;
    private double time;


    public Swimmer(String name, Sex sex, int age, double time) {
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.time = time;
        setAgeGroup();
    }

    private void setAgeGroup() {
        if(age >= 18 && age<= 21){
            this.ageGroup = AgeGroup.EIGHTEEN_TO_TWENTYONE;
        }else if(age >=22 && age <=25 ){
            this.ageGroup = AgeGroup.TWENTYTWO_TO_TWENTYFIVE;
        }else if(age >=26 && age <=29){
            this.ageGroup = AgeGroup.TWENTYSIX_TWENTYNINE;
        }else if(age >= 30){
            this.ageGroup = AgeGroup.THIRTHY_PLUS;
        }
    }

    public AgeGroup getAgeGroup() {
        return ageGroup;
    }

    private ArrayList<Game> games = new ArrayList<>();

    public ArrayList<Game> getGames() {
        return games;
    }

    public void setGames(ArrayList<Game> games) {

        this.games = games;
    }

    public void addGame(Game game) {
        this.games.add(game);
    }

    public void removeGame(Game game) {
        this.games.remove(game);
    }

    public String getName() {
        return name;
    }


    public Sex getSex() {
        return sex;
    }

    public int getAge() {
        return age;
    }


    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }
}
