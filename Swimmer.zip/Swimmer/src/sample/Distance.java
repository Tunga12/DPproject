package sample;

public enum Distance {

    TWO_HUNDRED_METER, THREE_HUNDRED_METER;
}
