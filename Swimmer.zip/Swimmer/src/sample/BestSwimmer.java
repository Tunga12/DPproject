package sample;

import java.util.ArrayList;
import java.util.Comparator;

public abstract class BestSwimmer {

    abstract ArrayList<Swimmer> filter( ArrayList<Swimmer> list);
    public ArrayList<String> sortByTime(ArrayList<Swimmer> list){

        list.sort(Comparator.comparing(o -> o.getTime()));
        ArrayList<String> sorted = new ArrayList<>();
        for(Swimmer swimmer: list){
            sorted.add(swimmer.getName() +"   " + swimmer.getTime());
        }
        return sorted;
    }

    public final ArrayList<String> sort(ArrayList<Swimmer> list){
        ArrayList<Swimmer> filtered_list = filter(list);
        return sortByTime(filtered_list);
    }
}
