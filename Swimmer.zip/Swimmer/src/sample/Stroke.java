package sample;

public enum Stroke {

    FORWARD, BACKWARD;
}
