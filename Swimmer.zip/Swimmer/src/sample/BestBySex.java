package sample;

import java.util.ArrayList;

public class BestBySex extends BestSwimmer {

    private Sex sex;

    public BestBySex(Sex sex) {
        this.sex = sex;
    }

    @Override
    public ArrayList<Swimmer> filter(ArrayList<Swimmer> list) {

        ArrayList<Swimmer> filtered = new ArrayList<>();
        for(Swimmer swimmer: list){
            if(swimmer.getSex()== this.sex){
                filtered.add(swimmer);
            }
        }


        return filtered;
    }
}
