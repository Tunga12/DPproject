package sample;

public enum Sex {

    MALE, FEMALE
}
