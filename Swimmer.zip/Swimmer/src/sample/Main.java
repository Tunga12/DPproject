package sample;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import static sample.AgeGroup.*;

public class Main extends Application {

    Button clone = new Button("clone");
    TextArea text1 = new TextArea();
    TextArea text2 = new TextArea();
    TextArea text3 = new TextArea();


    Scene scene,scene1;

    @Override
    public void start(Stage primaryStage) throws Exception{

        ArrayList swimmers = new ArrayList<>(
                Arrays.asList(
                        new Swimmer("Tunga", Sex.FEMALE, 27, 22.5),
                        new Swimmer("Eyerus", Sex.FEMALE, 26, 45.5),
                        new Swimmer("Nahom", Sex.MALE, 18, 23.5),

                        new Swimmer("Maramawit", Sex.FEMALE, 22, 14),
                        new Swimmer("Robel", Sex.MALE, 30, 18.6),
                        new Swimmer("Lidya", Sex.FEMALE, 21, 16.4)
                )

        );

        primaryStage.setTitle("Records of Swimmers");

        BestSwimmer bestBySex1 = new BestBySex(Sex.FEMALE);
        ArrayList<String> sorted1 = bestBySex1.sort( swimmers );

        BestSwimmer bestBySex2 = new BestBySex(Sex.MALE);
        ArrayList<String> sorted2 = bestBySex2.sort( swimmers );



       ChoiceBox<AgeGroup> groupBox = new ChoiceBox<>();
       groupBox.getItems().add(EIGHTEEN_TO_TWENTYONE);
       groupBox.getItems().add(TWENTYTWO_TO_TWENTYFIVE);
       groupBox.getItems().add(TWENTYSIX_TWENTYNINE);
       groupBox.getItems().add(THIRTHY_PLUS);

        Iterator<Swimmer> it = swimmers.iterator();
        int j=0;
        while(it.hasNext()){
            Swimmer element = it.next();
            text1.appendText(element.getName() +"\t" +element.getAge()+"\t" +element.getTime()+"\t" +element.getSex() + "\n");
            j++;
        }
        Iterator<String> it2 = sorted1.iterator();
        int i=0;
        while(it2.hasNext()){
            String element = it2.next();
            text2.appendText(element + "\n");
            i++;
        }


        RadioButton rb1 = new RadioButton();
        rb1.setText("F");
        RadioButton rb2 = new RadioButton();
        rb2.setText("M");

        ToggleGroup group = new ToggleGroup();
        rb1.setToggleGroup(group);
        rb2.setToggleGroup(group);
        rb1.setSelected(true);

        HBox hbox = new HBox(10);
        VBox vbox = new VBox(10);

        hbox.setPadding(new Insets(20,20,20,20));
        vbox.setPadding(new Insets(20,20,20,20));

        vbox.getChildren().addAll(groupBox,rb1,rb2);
        hbox.getChildren().addAll(text1,vbox,text2);


        scene1 = new Scene(hbox,900,400);

        groupBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<AgeGroup>() {

            @Override
            public void changed(ObservableValue<? extends AgeGroup> observable, AgeGroup oldValue, AgeGroup newValue) {
            text2.clear();
            BestSwimmer bestByAge1 = new BestByAge(newValue);

            ArrayList<String> sortedVals = bestByAge1.sort(swimmers );

            for(int t = 0;t < sortedVals.size();t++){
                System.out.println("the value is " +sortedVals.get(t));

            }

            Iterator<String> it4 = sortedVals.iterator();
             int l=0;
                while(it4.hasNext()){
                    String element = it4.next();
                    text2.appendText(element + "\n");
                    l++;
                }

                HBox hbox2 = new HBox(10);
                hbox2.getChildren().addAll(text1,vbox,text2);
                primaryStage.setScene(new Scene(hbox2,700,400));


        }});

        group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {

            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                if(group.getSelectedToggle() == rb1){
                    text2.clear();
                    Iterator<String> it3 = sorted1.iterator();
                    int m=0;
                    while(it3.hasNext()){
                        String element = it3.next();
                        text2.appendText(element + "\n");
                        m++;
                    }

                    HBox hbox2 = new HBox(10);
                    hbox2.getChildren().addAll(text1,vbox,text2);
                    primaryStage.setScene(new Scene(hbox2,700,400));

                }else if(group.getSelectedToggle() == rb2){
                    text2.clear();
                    Iterator<String> it3 = sorted2.iterator();
                    int m=0;
                    while(it3.hasNext()){
                        String element = it3.next();
                        text2.appendText(element + "\n");
                        m++;
                    }

                    HBox hbox3 = new HBox(10);
                    hbox3.getChildren().addAll(text1,vbox,text2);
                    primaryStage.setScene(new Scene(hbox3, 700,400));

                }
            }
        });

        primaryStage.setScene(scene1);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
