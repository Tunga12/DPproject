package sample;

public class Game {

    private Stroke stroke;
    private Distance distance;
    private double time;

    public Game(Stroke stroke, Distance distance, double time) {
        this.stroke = stroke;
        this.distance = distance;
        this.time = time;
    }

    public Stroke getStroke() {
        return stroke;
    }

    public void setStroke(Stroke stroke) {
        this.stroke = stroke;
    }

    public Distance getDistance() {
        return distance;
    }

    public void setDistance(Distance distance) {
        this.distance = distance;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }
}
