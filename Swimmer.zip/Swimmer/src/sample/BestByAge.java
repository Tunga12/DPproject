package sample;

import java.util.ArrayList;


public class BestByAge extends BestSwimmer {

    private AgeGroup ageGroup;

    public BestByAge(AgeGroup ageGroup) {
        this.ageGroup = ageGroup;
    }

    @Override
    public ArrayList<Swimmer> filter(ArrayList<Swimmer> list) {

        ArrayList<Swimmer> filtered = new ArrayList<>();
        for(Swimmer swimmer: list){
            if(swimmer.getAgeGroup() == this.ageGroup){
                filtered.add(swimmer);
            }
        }


        return filtered;
    }


}
