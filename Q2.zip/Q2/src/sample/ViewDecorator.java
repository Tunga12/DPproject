package sample;

import javafx.collections.ObservableList;

public abstract class ViewDecorator implements View {

    protected View DecoratedProduct;

    public ViewDecorator(View product){
            this.DecoratedProduct = product;

    }
    @Override
    public ObservableList<product> productName(ObservableList<product> list) {

            //DecoratedProduct.productName(list);
        return DecoratedProduct.productName(list);
    }
}
