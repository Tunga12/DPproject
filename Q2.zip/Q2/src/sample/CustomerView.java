package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CustomerView implements View {

    @Override
    public ObservableList<product> productName(ObservableList<product> list) {

        ObservableList<product> productNameOnly = FXCollections.observableArrayList();

        for(int i = 0 ; i < list.size();i++){
            productNameOnly.add(new product(list.get(i).getName()));

        }
        return productNameOnly;
    }
}
