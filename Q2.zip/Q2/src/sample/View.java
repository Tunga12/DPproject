package sample;

import javafx.collections.ObservableList;

interface View {

     ObservableList<product> productName(ObservableList<product> list);
}
