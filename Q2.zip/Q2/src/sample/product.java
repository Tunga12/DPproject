package sample;

public class product {

    String name;
    int bought;



   public product(){
        this.name = "";
        this.bought = 0;
       // int shipped=0;
    }
    public product(String name){
        this.name = name;

    }
    public product(int bought){
        this.bought = bought;

    }
    public product(String name, int bought){
        this.name = name;
        this.bought = bought;


    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBought() {
        return bought;
    }

    public void setBought(int bought) {
        this.bought = bought;
    }
}
