package sample;

import javafx.collections.ObservableList;

import java.util.Comparator;

public class Sort extends ViewDecorator {

    public Sort(View DecoratedProduct) {
        super(DecoratedProduct);
    }


    public ObservableList<product> productName(ObservableList<product> list) {

        DecoratedProduct.productName(list);
        return sort(list);
    }

    public ObservableList<product> sort(ObservableList<product> list){

        Comparator<product> comparator = Comparator.comparing(product::getName);
        list.sort(comparator);
        return list;

    }
}
