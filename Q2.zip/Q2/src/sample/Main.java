package sample;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    Button button = new Button("BUY");
    Button buttonSort = new Button("SORT");
    TableView<product> table,table2,table3;
    boolean isSorted=false;
    @Override
    public void start(Stage primaryStage) throws Exception{


        ObservableList<product> pro = FXCollections.observableArrayList();
        pro.add(new product("vans",0));
        pro.add(new product("skeacher",0));
        pro.add(new product("all star",0));
        pro.add(new product("slippers",0));
        pro.add(new product("snickers",0));

        Scene scene1;

        primaryStage.setTitle("FASHION STYLE PRODUCT LIST");

        TableColumn<product,String> colName = new TableColumn<>("name");
        colName.setMinWidth(200);
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<product,Integer> colBought = new TableColumn<>("bought");
        colBought.setMinWidth(200);
        colBought.setCellValueFactory(new PropertyValueFactory<>("bought"));


        View s = new CustomerView();
        View sb = new ExecutiveView(s);
        View sD = new Sort(s);

        table = new TableView<>();
        table.setItems(s.productName(pro));
        table.getColumns().addAll(colName);



        RadioButton rb1 = new RadioButton();
        rb1.setText("Customer View");
        RadioButton rb2 = new RadioButton();
        rb2.setText("executive view");

        ToggleGroup group = new ToggleGroup();
        rb1.setToggleGroup(group);
        rb2.setToggleGroup(group);
        rb1.setSelected(true);

        HBox layout1 = new HBox(10);
        HBox layout2 = new HBox(10);
        VBox layoutV2 = new VBox(10);
        VBox layoutV1 = new VBox(10);
        layout1.setPadding(new Insets(20,20,20,20));
        layout2.setPadding(new Insets(20,20,20,20));
        layoutV1.setPadding(new Insets(20,20,20,20));
        layoutV2.setPadding(new Insets(20,20,20,20));
        layout2.getChildren().addAll(rb1,rb2);
        layoutV1.getChildren().addAll(layout2,table,button,buttonSort);

        scene1 = new Scene(layoutV1,700,400);

        group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {

            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                if(group.getSelectedToggle() == rb1){

                    if(isSorted){
                        VBox layoutV123 = new VBox(10);
                        layoutV123.getChildren().addAll(layout2, table3, button, buttonSort);
                        primaryStage.setScene(new Scene(layoutV123, 700, 400));
                    }
                    else {
                        VBox layoutV123 = new VBox(10);
                        layoutV123.getChildren().addAll(layout2, table, button, buttonSort);
                        primaryStage.setScene(new Scene(layoutV123, 700, 400));
                    }
                }else if(group.getSelectedToggle() == rb2){

                        table2 = new TableView<>();
                        table2.setItems(sb.productName(table.getItems()));
                        table2.getColumns().addAll(colName, colBought);

                        VBox layoutV12 = new VBox(10);
                        layoutV12.getChildren().addAll(layout2, table2);
                        primaryStage.setScene(new Scene(layoutV12, 700, 400));
                }
            }
        });

        button.setOnAction(event -> {

              if(isSorted){
                    table3.getSelectionModel().getSelectedItem().setBought((table3.getSelectionModel().getSelectedItem().bought) + 1);
                    System.out.println("you have  bought " + table3.getSelectionModel().getSelectedItem().getName() + " " + table3.getSelectionModel().getSelectedItem().getBought() + " product");

                }
                else {
                  table.getSelectionModel().getSelectedItem().setBought((table.getSelectionModel().getSelectedItem().bought) + 1);
                  System.out.println("you have  bought " + table.getSelectionModel().getSelectedItem().getName() + " " + table.getSelectionModel().getSelectedItem().getBought() + " product");
              }
        });
        buttonSort.setOnAction(event -> {
            isSorted= true;
            table3 = new TableView<>();
            table3.setItems(sD.productName(table.getItems()));
            table3.getColumns().addAll(colName);
            VBox layoutV14 = new VBox(10);

            layoutV14.getChildren().addAll(layout2,table3,button,buttonSort);
            primaryStage.setScene(new Scene(layoutV14,700,400));

        });
        primaryStage.setScene(scene1);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
