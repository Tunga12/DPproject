package sample;

public class MenuIterator implements Iterator {

    private Menu menu;
    private int current = 0;
    // Constructor
    public MenuIterator(Menu menu)    {
        this.menu = menu;
    }


    public  Object First()    {
        current++;
        return menu.get(0);
    }

    public  Object Next()    {
        Object ret = null;
        if (current < menu.count()) {
            ret = menu.get(current);
            current++;
        }
        return ret;
    }
    public  Object CurrentItem()    {
        return menu.get(current);
    }

    public  boolean IsDone() {
        if (current >= menu.count()) {
            current = 0;
            return true;
        }

        return false;
    }

}
