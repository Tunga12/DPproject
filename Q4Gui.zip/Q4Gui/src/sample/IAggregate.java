package sample;

public interface IAggregate {
    Iterator createIterator();
}
