package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    ListView<String> menuList;
    @FXML
    TextField txtFoodNum, txtLatitude, txtLongitude;
    @FXML
    Button btnOrder;
    @FXML
    TextArea txtResult;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Menu menu = Menu.getInstance();
        Iterator menuIterator = menu.createIterator();


        menuList.getItems().add(menuIterator.First().toString());
        while(!menuIterator.IsDone()){
            menuList.getItems().add(menuIterator.Next().toString());
        }


    }

    public void orderClicked(){
        txtResult.setText("");
        txtFoodNum.setText("0");
        txtLatitude.setText("0");
        txtLongitude.setText("0");
        int num = Integer.parseInt(txtFoodNum.getText());
        double latitude = Double.parseDouble(txtLatitude.getText());
        double longitude = Double.parseDouble(txtLongitude.getText());

        OrderCenter.getInstance().order(num,latitude,longitude);
    }


    public void updateTextArea(String text){
        txtResult.appendText("\n" + text);
    }
}
