package sample;


import java.util.ArrayList;

public class Order implements ISubject{

    private Status status;
    private int payment;

    private ArrayList<IObserver> observers = new ArrayList<>();

    public Order(int payment){
        this.payment = payment;
        this.attach(OrderCenter.getInstance());
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {

        this.status = status;
        inform();
    }

    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }


    @Override
    public void attach(IObserver observer) {
        observers.add(observer);
    }

    @Override
    public void detach(IObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void inform() {
        for(IObserver observer : observers){
            observer.update(this);
        }
    }
}
