package sample;

public enum Status {

    PENDING, DELIVERED, FAILED
}
