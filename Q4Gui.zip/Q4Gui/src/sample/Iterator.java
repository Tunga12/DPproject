package sample;

public interface Iterator {

    Object First();
    Object Next();
    boolean IsDone();
    Object CurrentItem();

}
