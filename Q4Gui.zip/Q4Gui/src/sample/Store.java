package sample;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public  class Store {

    private String name;
    private double latitude;
    private double longitude;

    protected Store nextStore;

    private ArrayList<Order> orders = new ArrayList<>();


    public Store(String name, double latitude, double longitude) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }



    public void takeOrder(Order order) {

        if(orders.size() < 2){
            orders.add(order);
            handleOrder(order);
        }else if(nextStore != null){
            nextStore.takeOrder(order);
        }


    }

//    public void placeOrders(){
//
//        for(Order order: orders){
//            order.order();
//        }
//
//        orders.clear();
//    }

    public void handleOrder(Order order){

        try {
            order.setStatus(Status.PENDING);
            //System.out.println(order.getStatus());
            TimeUnit.SECONDS.sleep(5);
            order.setStatus(Status.DELIVERED);
            //System.out.println(order.getStatus());

            orders.remove(order);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void setNextStore(Store nextStore) {
        this.nextStore = nextStore;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
