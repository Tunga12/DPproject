package sample;

import java.util.ArrayList;

public class Menu implements IAggregate{

    private static Menu instance = new Menu();

    private ArrayList<String> menuItems = new ArrayList<>();


    private Menu(){
        this.add("1. Chicken sandwich.   price: 50.00 birr");
        this.add("2. Beaf sandwich.      price: 60.00 birr");
        this.add("3. Fish sandwich.      price: 70.00 birr");
        this.add("4. Soft Drink.         price: 10.00 birr");
        this.add("5. coffee.             price: 7.00 birr ");
        this.add("6. tea.                price: 5.00 birr ");

    }

    public static Menu getInstance(){      return instance;   }


    public String get(int pos){
        return menuItems.get(pos);
    }

    public void add( String s){
        menuItems.add(s);
    }

    public int count(){
        return menuItems.size();
    }

    public int numToPrice(int num){
        switch (num){
            case 1: return 50;
            case 2: return 60;
            case 3: return 70;
            case 4: return 10;
            case 5: return 7;
            case 6: return 5;

            default: return 0;

        }
    }


    @Override
    public Iterator createIterator() {
        return new MenuIterator(this);
    }
}
