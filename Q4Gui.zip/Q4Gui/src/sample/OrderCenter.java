package sample;

import javafx.fxml.FXMLLoader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class OrderCenter  implements IObserver {

    double R = 6.37;

    //for singleton pattern
    private static OrderCenter instance = new OrderCenter();

    ArrayList<Store> stores = new ArrayList<>(
            Arrays.asList(
                    new Store("Store1", 12, 16),
                    new Store("Store2", 15, 96),
                    new Store("Store3", 51, 44)
            )
    );

    private OrderCenter() { }

    public static OrderCenter getInstance(){
        return instance;
    }


    public void order(int num, double latitude, double longitude ){

        stores.sort(Comparator.comparing(o -> calculateDistance(latitude, longitude, o.getLatitude(),o.getLongitude())));
        for(int i =0; i<stores.size(); i++){
            if(i != stores.size() -1){
                stores.get(i).setNextStore(stores.get(i+1));
            }else{
                stores.get(i).setNextStore(null);
            }

        }

        Main.controller.updateTextArea("I have chosen: " + stores.get(0).getName());


        Order order = new Order(Menu.getInstance().numToPrice(num));

        stores.get(0).takeOrder(order);


    }

    public double calculateDistance(double latitude1, double longitude1, double latitude2, double longitude2){

        double a = Math.sin((latitude2 - latitude1)/2) + Math.cos(latitude1) * Math.cos(latitude2) * Math.pow(Math.sin((longitude2 - longitude1) /2), 2);

        double c = Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        return R *c;

    }

    //for observer pattern
    public void update(Order order){
        Main.controller.updateTextArea("Order status has been changed to: " + order.getStatus());
    }



}
