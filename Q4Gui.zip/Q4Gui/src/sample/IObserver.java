package sample;

public interface IObserver {

     void update(Order order);
}
